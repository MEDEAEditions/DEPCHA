# DEPCHA

Author: Christopher Pollin 


# Wheaton to DEPCHA

missing TEIs: 	12-99 and 140-159
ToDo: 			in ToDo_TEI's
done: 			in depcha_1.xml (use xpath //pb to get all pages)

Workflow: 		take files in ToDo_TEI, bring it to the schema like in wheaton_template.xml, delete file in ToDo_TEI and add it to done_TEIs.

